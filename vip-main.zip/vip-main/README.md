

### INSTALL SCRIPT 
<pre><code>apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/QueenGoo/Autoscript/main/premi.sh && chmod +x premi.sh && ./premi.sh
</code></pre>

### PERINTAH UPDATE 
<pre><code>wget https://raw.githubusercontent.com/QueenGoo/Autoscript/main/update.sh && chmod +x update.sh && ./update.sh</code></pre>

